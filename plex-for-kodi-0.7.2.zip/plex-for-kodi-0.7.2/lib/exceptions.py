# coding=utf-8

class NoDataException(Exception):
    pass
