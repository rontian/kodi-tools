# 网易云音乐 Kodi 插件

### 截图

![主页](https://cdn.jsdelivr.net/gh/chen310/plugin.audio.music163/public/home.png)
![歌单](https://cdn.jsdelivr.net/gh/chen310/plugin.audio.music163/public/playlist.png)
![播放歌曲](https://cdn.jsdelivr.net/gh/chen310/plugin.audio.music163/public/song.png)
![播放MV](https://cdn.jsdelivr.net/gh/chen310/plugin.audio.music163/public/mv.png)
![设置](https://cdn.jsdelivr.net/gh/chen310/plugin.audio.music163/public/settings.png)

### 下载

到 [Actions](https://github.com/chen310/plugin.audio.music163/actions) 或 [Releases](https://github.com/chen310/plugin.audio.music163/releases) 中下载
